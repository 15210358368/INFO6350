//
//  WeatherInformationTableViewCell.swift
//  midterm6350
//
//  Created by Connor Wang on 11/19/22.
//

import UIKit

class WeatherInformationTableViewCell: UITableViewCell {

    @IBOutlet weak var lblText: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
